package org.example;

import com.galanz.iot.common.security.DecoderException;
import com.galanz.iot.common.security.GlzAESEncryptor;
import com.galanz.iot.common.security.GlzKeyGenerator;
import com.galanz.iot.common.security.Hex;
import org.junit.Test;

public class SecurityTest {

    @Test
    public void sample() throws DecoderException {
        // SecretKey
        String secretKeyCipherText = GlzKeyGenerator.generateSecretKey();
        System.out.println("secretKeyCipherText: " + secretKeyCipherText);
        String secretKey = GlzKeyGenerator.decryptSecretKeys(secretKeyCipherText);
        System.out.println("secretKey: " + secretKey);

        // Secret is encrypted by DID
        String did = "89860000120000000061";
        System.out.println("secretMessage: " + did);
        String secret = GlzAESEncryptor.encrypt(did, secretKey);
        System.out.println("secret: " + secret);

        // Secret to decrypt
        String secretCipherText = GlzAESEncryptor.decrypt(Hex.decodeHex(secret), secretKey);
        System.out.println("secretToDecrypt: " + secretCipherText);
    }
}
