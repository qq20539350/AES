//
//  NSString+AES.h
//  jiajiemiTest
//
//  Created by lwf on 2020/11/7.
//  Copyright © 2020 10.12. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (AES)

+ (NSString *)getSecretKey;

+ (NSString *)decryptSecretKey:(NSString *)secretKey;

+ (NSString *)AES128_EncryptWithMessage:(NSString *)message key:(NSString *)key;

+ (NSString *)AES128_DecryptWithMessage:(NSString *)message key:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
